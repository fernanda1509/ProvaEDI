# Atividade 2023 - Semestre 2

Realize a atividade conforme instruções descritas na [atividade](Atividade/docs/2023.2%20-%20Av1%20-%20Parte1.pdf)

## Executando o teste automático

É possível executar um teste automático para validar a completude do envio do seu código. Para isso vá na aba [Actions](https://github.com/CBSIIFSLagarto/2023_2_ED_ProvaAv1Parte1/actions) e execute a tarefa `Java CI with Maven`. Ela irá testar seu código com a bateria de testes disponibilizada no repositório.

> Atenção: Para funcionar você deverá manter a estrutura de arquivos.
