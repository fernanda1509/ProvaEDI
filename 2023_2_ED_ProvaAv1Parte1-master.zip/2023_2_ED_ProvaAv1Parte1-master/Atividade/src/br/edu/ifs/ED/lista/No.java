package br.edu.ifs.ED.lista;

public class No<T> {
    public T dado;
    public No<T> proximo;
}
